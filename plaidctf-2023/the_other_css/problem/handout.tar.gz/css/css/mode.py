from enum import Enum


class Mode(Enum):
    Authentication = 1
    DiskKey = 2
    TitleKey = 3
    Data = 4
